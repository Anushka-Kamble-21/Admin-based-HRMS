function Topbar() {
  return (
    <header className="h-16 bg-white shadow-sm flex items-center justify-between px-6">
      <h1 className="text-lg font-semibold">Admin Dashboard</h1>

      <div className="text-sm text-gray-500">
        Welcome, Admin
      </div>
    </header>
  );
}

export default Topbar;
