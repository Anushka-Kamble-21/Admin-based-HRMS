import { useState } from "react";
import { attendanceRecords as mockData } from "../../../services/mocks/mockAttendance";

const Attendance = () => {
  const [records, setRecords] = useState(mockData);

  const handleChange = (id, field, value) => {
    setRecords((prev) =>
      prev.map((rec) =>
        rec.id === id ? { ...rec, [field]: value } : rec
      )
    );
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Attendance</h1>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl shadow-sm flex gap-4">
        <input type="date" className="border p-2 rounded" />

        <select className="border p-2 rounded">
          <option>All Departments</option>
          <option>HR</option>
          <option>Engineering</option>
          <option>Sales</option>
        </select>
      </div>

      {/* Editable Attendance Table */}
      <div className="bg-white rounded-xl shadow-sm overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-3 text-left">Employee</th>
              <th className="p-3">Department</th>
              <th className="p-3">Date</th>
              <th className="p-3">Login</th>
              <th className="p-3">Logout</th>
              <th className="p-3">Attendance</th>
              <th className="p-3">Punctuality</th>
            </tr>
          </thead>

          <tbody>
            {records.map((rec) => (
              <tr key={rec.id} className="border-t">
                <td className="p-3">{rec.employeeName}</td>

                <td className="p-3 text-center">
                  {rec.department}
                </td>

                <td className="p-3 text-center">
                  {rec.date}
                </td>

                {/* Login Time */}
                <td className="p-3 text-center">
                  <input
                    type="time"
                    value={rec.loginTime || ""}
                    onChange={(e) =>
                      handleChange(
                        rec.id,
                        "loginTime",
                        e.target.value
                      )
                    }
                    className="border p-1 rounded"
                  />
                </td>

                {/* Logout Time */}
                <td className="p-3 text-center">
                  <input
                    type="time"
                    value={rec.logoutTime || ""}
                    onChange={(e) =>
                      handleChange(
                        rec.id,
                        "logoutTime",
                        e.target.value
                      )
                    }
                    className="border p-1 rounded"
                  />
                </td>

                {/* Attendance Status */}
                <td className="p-3 text-center">
                  <select
                    value={rec.attendanceStatus}
                    onChange={(e) =>
                      handleChange(
                        rec.id,
                        "attendanceStatus",
                        e.target.value
                      )
                    }
                    className="border p-1 rounded"
                  >
                    <option>Present</option>
                    <option>Half Day</option>
                    <option>Absent</option>
                    <option>WFH</option>
                  </select>
                </td>

                {/* Punctuality */}
                <td className="p-3 text-center">
                  <select
                    value={rec.punctuality || ""}
                    onChange={(e) =>
                      handleChange(
                        rec.id,
                        "punctuality",
                        e.target.value
                      )
                    }
                    className="border p-1 rounded"
                  >
                    <option value="">—</option>
                    <option>On Time</option>
                    <option>Late</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mock Save Info */}
      <p className="text-sm text-gray-500">
        Changes are saved locally (mock). Backend integration will persist updates.
      </p>
    </div>
  );
};

export default Attendance;
