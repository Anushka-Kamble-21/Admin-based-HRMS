import AttendanceChart from "../../../components/charts/AttendanceChart";
import SalaryChart from "../../../components/charts/SalaryChart";
import DashboardTopCards from "./DashboardTopCards";
import DepartmentChart from "../../../components/charts/DepartmentChart";
import HRCalendar from "../../../components/common/HRCalendar";
import TodaySummary from "../../../components/common/TodaySummary";
import PendingActions from "../../../components/common/PendingActions";

const Dashboard = () => {
  const loading = false;

  const stats = {
    totalEmployees: 200,
    onLeaveToday: 12,
    salaryStatus: {
      processed: 150,
      pending: 50
    }
  };

  const attendanceData = [
    { month: "Jan", present: 180, absent: 12, onLeave: 8 },
    { month: "Feb", present: 170, absent: 20, onLeave: 10 },
    { month: "Mar", present: 185, absent: 10, onLeave: 5 }
  ];

  const salaryData = [
    { month: "Jan", paid: 150, pending: 50 },
    { month: "Feb", paid: 170, pending: 30 },
    { month: "Mar", paid: 180, pending: 20 }
  ];

  const departmentData = [
    { department: "HR", count: 20 },
    { department: "Engineering", count: 90 },
    { department: "Sales", count: 40 },
    { department: "Finance", count: 15 }
  ];

  const calendarEvents = [
    {
      date: "15 Jan",
      title: "Republic Day Holiday",
      type: "Holiday"
    },
    {
      date: "20 Jan",
      title: "Payroll Processing",
      type: "Salary"
    },
    {
      date: "22 Jan",
      title: "5 Employees on Leave",
      type: "Leave"
    }
  ];

  const todaySummaryData = {
    present: 165,
    absent: 12,
    onLeave: 18,
    late: 5
  };

  const pendingActionsData = {
    pendingLeaves: 7,
    pendingSalaries: 18
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">
        Admin Dashboard
      </h1>

      {/* 🔹 TOP CARDS */}
      <DashboardTopCards
        data={stats}
        loading={loading}
      />

      {/* 🔹 CHARTS SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h2 className="font-semibold mb-4">
            Attendance Overview
          </h2>
          <AttendanceChart data={attendanceData} />
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h2 className="font-semibold mb-4">
            Salary Overview
          </h2>
          <SalaryChart data={salaryData} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <h2 className="font-semibold mb-4">Departments</h2>
            <DepartmentChart data={departmentData} />
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <h2 className="font-semibold mb-4">Calendar</h2>
            <HRCalendar events={calendarEvents} />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <TodaySummary data={todaySummaryData} loading={loading} />
          <PendingActions data={pendingActionsData} loading={loading} />
        </div>

      </div>
    </div>
  );
};

export default Dashboard;
