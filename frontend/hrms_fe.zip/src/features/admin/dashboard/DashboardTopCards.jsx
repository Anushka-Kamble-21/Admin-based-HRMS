import DashboardCard from "../../../components/common/DashboardCard";

const DashboardTopCards = ({ data, loading }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <DashboardCard
        title="Total Employees"
        value={data?.totalEmployees}
        subtitle="Active employees"
        loading={loading}
      />

      <DashboardCard
        title="On Leave Today"
        value={data?.onLeaveToday}
        subtitle="Across all departments"
        loading={loading}
      />

      <DashboardCard
        title="Employee Management"
        value={data?.totalEmployees}
        subtitle="View & manage employees"
        actionText="Manage Employees"
        onAction={() => console.log("Go to employees")}
        loading={loading}
      />

      <DashboardCard
        title="Salary Management"
        value={`${data?.salaryStatus?.processed}/${data?.totalEmployees}`}
        subtitle="Salaries processed"
        actionText="Go to Payroll"
        onAction={() => console.log("Go to payroll")}
        loading={loading}
      />
    </div>
  );
};

export default DashboardTopCards;
