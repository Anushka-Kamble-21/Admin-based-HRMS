import { NavLink, Outlet } from "react-router-dom";

const Profile = () => {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6 flex min-h-[500px]">
      <aside className="w-64 border-r pr-4">
        <h2 className="font-semibold mb-4">Profile</h2>

        <nav className="space-y-2 text-sm">
          <NavLink to="personal" className="block">Personal Details</NavLink>
          <NavLink to="contact" className="block">Contact Details</NavLink>
          <NavLink to="education" className="block">Education</NavLink>
          <NavLink to="job" className="block">Job Details</NavLink>
          <NavLink to="update" className="block">Update Profile</NavLink>
        </nav>
      </aside>

      <section className="flex-1 pl-6">
        <Outlet />
      </section>
    </div>
  );
};

export default Profile;
