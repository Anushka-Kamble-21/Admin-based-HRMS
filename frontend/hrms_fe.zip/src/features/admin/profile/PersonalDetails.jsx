const PersonalDetails = () => {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Personal Details</h3>

      <div className="grid grid-cols-2 gap-6 text-sm">
        <div>
          <p className="text-gray-500">Full Name</p>
          <p className="font-medium">Andrew Miles</p>
        </div>

        <div>
          <p className="text-gray-500">Date of Birth</p>
          <p className="font-medium">12 Aug 1998</p>
        </div>

        <div>
          <p className="text-gray-500">Gender</p>
          <p className="font-medium">Male</p>
        </div>

        <div>
          <p className="text-gray-500">Marital Status</p>
          <p className="font-medium">Single</p>
        </div>
      </div>
    </div>
  );
};

export default PersonalDetails;
