const JobDetails = () => {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Job Details</h3>

      <div className="grid grid-cols-2 gap-6 text-sm">
        <div>
          <p className="text-gray-500">Role</p>
          <p className="font-medium">HR Manager</p>
        </div>

        <div>
          <p className="text-gray-500">Department</p>
          <p className="font-medium">Human Resources</p>
        </div>

        <div>
          <p className="text-gray-500">Joining Date</p>
          <p className="font-medium">01 Jan 2023</p>
        </div>

        <div>
          <p className="text-gray-500">Employment Type</p>
          <p className="font-medium">Full Time</p>
        </div>

        <div>
          <p className="text-gray-500">Salary</p>
          <p className="font-medium">₹45,000 / month</p>
        </div>
      </div>
    </div>
  );
};

export default JobDetails;
