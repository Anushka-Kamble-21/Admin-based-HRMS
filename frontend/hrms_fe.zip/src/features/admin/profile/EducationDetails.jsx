const EducationDetails = () => {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">
        Educational Qualifications
      </h3>

      <ul className="space-y-4 text-sm">
        <li>
          <p className="font-medium">B.E. Computer Engineering</p>
          <p className="text-gray-500">
            University of Pune | 2020 – 2024
          </p>
        </li>

        <li>
          <p className="font-medium">HSC – Science</p>
          <p className="text-gray-500">
            Maharashtra Board | 2018 – 2020
          </p>
        </li>
      </ul>
    </div>
  );
};

export default EducationDetails;
