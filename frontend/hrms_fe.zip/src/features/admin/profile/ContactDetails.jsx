const ContactDetails = () => {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Contact Details</h3>

      <div className="grid grid-cols-2 gap-6 text-sm">
        <div>
          <p className="text-gray-500">Email</p>
          <p className="font-medium">andrew@mail.com</p>
        </div>

        <div>
          <p className="text-gray-500">Phone</p>
          <p className="font-medium">+91 98765 43210</p>
        </div>

        <div className="col-span-2">
          <p className="text-gray-500">Address</p>
          <p className="font-medium">
            Mumbai, Maharashtra, India
          </p>
        </div>
      </div>
    </div>
  );
};

export default ContactDetails;
