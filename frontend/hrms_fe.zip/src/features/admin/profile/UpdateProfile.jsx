const UpdateProfile = () => {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Update Profile</h3>

      <form className="grid grid-cols-2 gap-6">
        <input className="border p-2 rounded" placeholder="Full Name" />
        <input className="border p-2 rounded" placeholder="Email" />
        <input className="border p-2 rounded" placeholder="Phone" />
        <input className="border p-2 rounded" placeholder="Department" />
        <button className="col-span-2 bg-black text-white py-2 rounded">
          Save Changes
        </button>
      </form>
    </div>
  );
};

export default UpdateProfile;
