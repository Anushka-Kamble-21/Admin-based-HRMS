const Payroll = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Payroll Management</h1>

      <div className="bg-white p-4 rounded-xl shadow-sm flex gap-4">
        <select className="border p-2 rounded">
          <option>January 2026</option>
          <option>February 2026</option>
          <option>March 2026</option>
        </select>

        <select className="border p-2 rounded">
          <option>All Departments</option>
          <option>HR</option>
          <option>Engineering</option>
          <option>Sales</option>
        </select>
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-3 text-left">Employee</th>
              <th className="p-3">Department</th>
              <th className="p-3">Basic</th>
              <th className="p-3">Allowances</th>
              <th className="p-3">Deductions</th>
              <th className="p-3">Net Pay</th>
              <th className="p-3">Status</th>
              <th className="p-3">Payslip</th>
            </tr>
          </thead>

          <tbody>
            <tr className="border-t">
              <td className="p-3">Andrew Miles</td>
              <td className="p-3 text-center">HR</td>
              <td className="p-3 text-center">₹30,000</td>
              <td className="p-3 text-center">₹5,000</td>
              <td className="p-3 text-center">₹2,000</td>
              <td className="p-3 text-center font-semibold">
                ₹33,000
              </td>
              <td className="p-3 text-center text-green-600">
                Paid
              </td>
              <td className="p-3 text-center">
                <button className="px-3 py-1 bg-black text-white rounded">
                  View
                </button>
              </td>
            </tr>

            <tr className="border-t">
              <td className="p-3">Kristin James</td>
              <td className="p-3 text-center">Engineering</td>
              <td className="p-3 text-center">₹40,000</td>
              <td className="p-3 text-center">₹8,000</td>
              <td className="p-3 text-center">₹3,000</td>
              <td className="p-3 text-center font-semibold">
                ₹45,000
              </td>
              <td className="p-3 text-center text-yellow-600">
                Pending
              </td>
              <td className="p-3 text-center">
                <button className="px-3 py-1 bg-gray-300 rounded">
                  —
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Payroll;
