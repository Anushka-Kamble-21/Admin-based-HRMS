import { useState } from "react";
import EditLeaveModal from "./EditLeaveModal";

const LeaveTable = ({ leaves, onUpdate, onRevert }) => {
  const [editIndex, setEditIndex] = useState(null);

  return (
    <div className="border rounded-md overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-gray-100">
          <tr>
            <th className="p-2 text-left">Employee</th>
            <th>Date</th>
            <th>Duration</th>
            <th>Status</th>
            <th>Sandwich</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {leaves.map((l, i) => (
            <tr key={i} className="border-t">
              <td className="p-2">{l.employeeId}</td>
              <td>{l.date}</td>
              <td>{l.duration}</td>
              <td className={l.paid ? "text-green-600" : "text-red-600"}>
                {l.paid ? "Paid" : "Unpaid"}
              </td>
              <td>{l.sandwichApplied ? l.sandwichDays.join(", ") : "—"}</td>
              <td className="space-x-2">
                <button
                  onClick={() => setEditIndex(i)}
                  className="text-blue-600"
                >
                  Edit
                </button>
                <button
                  onClick={() => onRevert(i)}
                  className="text-red-600"
                >
                  Revert
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {editIndex !== null && (
        <EditLeaveModal
          leave={leaves[editIndex]}
          onSave={(updated) => onUpdate(editIndex, updated)}
          onClose={() => setEditIndex(null)}
        />
      )}
    </div>
  );
};

export default LeaveTable;
