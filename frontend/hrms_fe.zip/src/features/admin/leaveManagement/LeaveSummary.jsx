const LeaveSummary = ({ leaves }) => {
  const paid = leaves.filter(l => l.paid).length;
  const unpaid = leaves.length - paid;

  return (
    <div className="flex gap-4">
      <div className="border p-4 rounded-md">Total: {leaves.length}</div>
      <div className="border p-4 rounded-md text-green-600">Paid: {paid}</div>
      <div className="border p-4 rounded-md text-red-600">Unpaid: {unpaid}</div>
    </div>
  );
};

export default LeaveSummary;
