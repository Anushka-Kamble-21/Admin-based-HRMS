import { useState } from "react";
import {employees} from "../../../services/mocks/mockEmployees";
import mockLeaveUsage from "../../../services/mocks/mockLeaves";
import { isPaidLeave } from "./utils/leavePolicy";
import { getSandwichDays } from "./utils/sandwichRule";

const AddLeaveForm = ({ onAddLeave }) => {
  const [form, setForm] = useState({
    employeeId: "",
    date: "",
    duration: 1,
    reason: ""
  });

  const usedLeaves = mockLeaveUsage[form.employeeId] || 0;
  const paid = isPaidLeave(usedLeaves, form.duration);
  const sandwichDays = form.date ? getSandwichDays(form.date) : [];

  const submitHandler = () => {
    if (!form.employeeId || !form.date || !form.reason) return;

    onAddLeave({
      ...form,
      paid,
      sandwichApplied: sandwichDays.length > 0,
      sandwichDays,
      createdAt: new Date().toISOString()
    });

    setForm({ employeeId: "", date: "", duration: 1, reason: "" });
  };

  return (
    <div className="border p-4 rounded-md space-y-3">
      <h2 className="font-medium">Add Leave</h2>

      <select
        className="w-full border p-2"
        value={form.employeeId}
        onChange={(e) => setForm({ ...form, employeeId: e.target.value })}
      >
        <option value="">Select Employee</option>
        {employees.map((e) => (
          <option key={e.id} value={e.id}>{e.name}</option>
        ))}
      </select>

      <input
        type="date"
        className="w-full border p-2"
        value={form.date}
        onChange={(e) => setForm({ ...form, date: e.target.value })}
      />

      <select
        className="w-full border p-2"
        value={form.duration}
        onChange={(e) =>
          setForm({ ...form, duration: Number(e.target.value) })
        }
      >
        <option value={1}>Full Day</option>
        <option value={0.5}>Half Day</option>
      </select>

      <input
        type="text"
        placeholder="Reason"
        className="w-full border p-2"
        value={form.reason}
        onChange={(e) => setForm({ ...form, reason: e.target.value })}
      />

      <div className="text-sm">
        <p>Status: <span className={paid ? "text-green-600" : "text-red-600"}>
          {paid ? "Paid" : "Unpaid"}
        </span></p>

        {sandwichDays.length > 0 && (
          <p className="text-red-500">
            Sandwich Applied: {sandwichDays.join(", ")}
          </p>
        )}
      </div>

      <button
        onClick={submitHandler}
        className="bg-black text-white px-4 py-2 rounded"
      >
        Add Leave
      </button>
    </div>
  );
};

export default AddLeaveForm;
