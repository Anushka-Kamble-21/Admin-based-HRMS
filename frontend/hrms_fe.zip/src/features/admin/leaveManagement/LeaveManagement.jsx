import { useState } from "react";
import AddLeaveForm from "./AddLeaveForm";
import LeaveTable from "./LeaveTable";
import LeaveSummary from "./LeaveSummary";
import LeaveFilters from "./LeaveFilters";
import { employees } from "../../../services/mocks/mockEmployees";

const LeaveManagement = () => {
  const [leaves, setLeaves] = useState([]);
  const [filters, setFilters] = useState({
    department:"",
    month: "",
    search:""
  });

  const addLeave = (leave) => {
    setLeaves((prev) => [...prev, { ...leave, isActive: true }]);
  };

  const updateLeave = (index, updatedLeave) => {
    setLeaves((prev) =>
      prev.map((l, i) => (i === index ? updatedLeave : l))
    );
  };

  const revertLeave = (index) => {
    setLeaves((prev) =>
      prev.map((l, i) =>
        i === index ? { ...l, isActive: false } : l
      )
    );
  };

  const filteredLeaves = leaves.filter((l) => {
    if (!l.isActive) return false;

    const employee = employees.find((e) => e.id === l.employeeId);
    if (!employee) return false;

    const leaveMonth = l.date.slice(0, 7);

    if (filters.department && employee.department !== filters.department)
      return false;

    if (filters.month && leaveMonth !== filters.month)
      return false;

    if (
      filters.search &&
      !employee.name.toLowerCase().includes(filters.search.toLowerCase())
    )
      return false;

    return true;
  });

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-semibold">Leave Management</h1>

      <LeaveSummary leaves={filteredLeaves} />

      <LeaveFilters filters={filters} setFilters={setFilters} />

      <AddLeaveForm onAddLeave={addLeave} />

      <LeaveTable
        leaves={filteredLeaves}
        onUpdate={updateLeave}
        onRevert={revertLeave}
      />
    </div>
  );
};

export default LeaveManagement;