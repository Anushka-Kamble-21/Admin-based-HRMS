import { useState } from "react";

const EditLeaveModal = ({ leave, onSave, onClose }) => {
  const [form, setForm] = useState({ ...leave });

  const save = () => {
    onSave(form);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center">
      <div className="bg-white p-6 rounded-md space-y-4 w-96">
        <h2 className="font-semibold">Edit Leave</h2>

        <input
          type="date"
          className="w-full border p-2"
          value={form.date}
          onChange={(e) => setForm({ ...form, date: e.target.value })}
        />

        <select
          className="w-full border p-2"
          value={form.duration}
          onChange={(e) =>
            setForm({ ...form, duration: Number(e.target.value) })
          }
        >
          <option value={1}>Full Day</option>
          <option value={0.5}>Half Day</option>
        </select>

        <input
          type="text"
          className="w-full border p-2"
          value={form.reason}
          onChange={(e) => setForm({ ...form, reason: e.target.value })}
        />

        <div className="flex justify-end gap-2">
          <button onClick={onClose} className="border px-3 py-1">
            Cancel
          </button>
          <button
            onClick={save}
            className="bg-black text-white px-3 py-1"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditLeaveModal;
