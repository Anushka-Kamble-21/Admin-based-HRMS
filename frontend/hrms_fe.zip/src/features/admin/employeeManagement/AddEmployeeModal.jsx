import { useState } from "react";

const AddEmployeeModal = ({ onClose, onAdd }) => {
  const [form, setForm] = useState({
    name: "",
    department: "",
    designation: "",
    dateOfJoining: "",
    salary: ""
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = () => {
    onAdd({
      id: Date.now().toString(),
      ...form,
      status: "Active"
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-xl w-full max-w-md">
        <h2 className="text-lg font-semibold mb-4">
          Add Employee
        </h2>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <input
            name="name"
            placeholder="Name"
            className="border p-2 rounded"
            onChange={handleChange}
          />

          <input
            name="department"
            placeholder="Department"
            className="border p-2 rounded"
            onChange={handleChange}
          />

          <input
            name="designation"
            placeholder="Designation"
            className="border p-2 rounded"
            onChange={handleChange}
          />

          <input
            type="date"
            name="dateOfJoining"
            className="border p-2 rounded"
            onChange={handleChange}
          />

          <input
            name="salary"
            placeholder="Salary"
            className="border p-2 rounded col-span-2"
            onChange={handleChange}
          />
        </div>

        <div className="mt-6 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded border"
          >
            Cancel
          </button>

          <button
            onClick={handleSubmit}
            className="bg-black text-white px-4 py-2 rounded"
          >
            Add
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddEmployeeModal;
