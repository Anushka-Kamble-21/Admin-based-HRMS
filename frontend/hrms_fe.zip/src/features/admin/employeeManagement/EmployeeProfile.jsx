import { useParams } from "react-router-dom";
import { employees } from "../../../services/mocks/mockEmployees";
import { useState } from "react";

const EmployeeProfile = () => {
  const { id } = useParams();
  const employee = employees.find((e) => e.id === id);
  const [form, setForm] = useState(employee);

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm max-w-4xl">
      <h1 className="text-xl font-semibold mb-6">
        Employee Profile
      </h1>

      {/* Personal & Job Details */}
      <div className="mb-8">
        <h2 className="font-medium mb-4">
          Personal & Job Details
        </h2>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <label className="text-gray-500">Name</label>
            <input
              value={form.name}
              onChange={(e) =>
                handleChange("name", e.target.value)
              }
              className="border p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-gray-500">Department</label>
            <input
              value={form.department}
              onChange={(e) =>
                handleChange("department", e.target.value)
              }
              className="border p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-gray-500">Designation</label>
            <input
              value={form.designation}
              onChange={(e) =>
                handleChange("designation", e.target.value)
              }
              className="border p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-gray-500">
              Date of Joining
            </label>
            <input
              type="date"
              value={form.dateOfJoining}
              onChange={(e) =>
                handleChange("dateOfJoining", e.target.value)
              }
              className="border p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-gray-500">Salary</label>
            <input
              value={form.salary}
              onChange={(e) =>
                handleChange("salary", e.target.value)
              }
              className="border p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-gray-500">
              Date of Birth
            </label>
            <input
              type="date"
              value={form.dob}
              onChange={(e) =>
                handleChange("dob", e.target.value)
              }
              className="border p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-gray-500">Status</label>
            <input
              value={form.status}
              disabled
              className="border p-2 rounded w-full bg-gray-100"
            />
          </div>
        </div>
      </div>

      {/* Bank Details */}
      <div className="mb-8">
        <h2 className="font-medium mb-4">
          Bank Details
        </h2>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <label className="text-gray-500">Bank Name</label>
            <input
              value={form.bankName || ""}
              onChange={(e) =>
                handleChange("bankName", e.target.value)
              }
              className="border p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-gray-500">Branch</label>
            <input
              value={form.branch || ""}
              onChange={(e) =>
                handleChange("branch", e.target.value)
              }
              className="border p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-gray-500">
              Account Number
            </label>
            <input
              value={form.accountNumber || ""}
              onChange={(e) =>
                handleChange("accountNumber", e.target.value)
              }
              className="border p-2 rounded w-full"
            />
          </div>

          <div>
            <label className="text-gray-500">IFSC Code</label>
            <input
              value={form.ifsc || ""}
              onChange={(e) =>
                handleChange("ifsc", e.target.value)
              }
              className="border p-2 rounded w-full"
            />
          </div>
        </div>
      </div>

      {/* Update Button */}
      <div className="text-right">
        <button className="bg-black text-white px-6 py-2 rounded">
          Update Profile
        </button>
      </div>
    </div>
  );
};

export default EmployeeProfile;
