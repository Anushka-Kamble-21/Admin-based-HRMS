import { useState } from "react";
import { employees as mockEmployees } from "../../../services/mocks/mockEmployees";
import AddEmployeeModal from "./AddEmployeeModal";
import { useNavigate } from "react-router-dom";

const EmployeeManagement = () => {
  const [employees, setEmployees] = useState(mockEmployees);
  const [departmentFilter, setDepartmentFilter] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);

  const navigate = useNavigate();

  const toggleStatus = (id) => {
    setEmployees((prev) =>
      prev.map((emp) =>
        emp.id === id
          ? {
              ...emp,
              status: emp.status === "Active" ? "Disabled" : "Active"
            }
          : emp
      )
    );
  };

  const filteredEmployees = departmentFilter
    ? employees.filter(
        (emp) => emp.department === departmentFilter
      )
    : employees;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">
        Employee Management
      </h1>

      {/* Top bar */}
      <div className="bg-white p-4 rounded-xl shadow-sm flex justify-between items-center">
        <select
          className="border p-2 rounded"
          value={departmentFilter}
          onChange={(e) => setDepartmentFilter(e.target.value)}
        >
          <option value="">All Departments</option>
          <option value="HR">HR</option>
          <option value="Engineering">Engineering</option>
          <option value="Sales">Sales</option>
        </select>

        <button
          className="bg-black text-white px-4 py-2 rounded"
          onClick={() => setShowAddModal(true)}
        >
          + Add Employee
        </button>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-3 text-left">Name</th>
              <th className="p-3">Department</th>
              <th className="p-3">Designation</th>
              <th className="p-3">Status</th>
              <th className="p-3">Actions</th>
            </tr>
          </thead>

          <tbody>
            {filteredEmployees.map((emp) => (
              <tr key={emp.id} className="border-t">
                <td className="p-3">{emp.name}</td>
                <td className="p-3 text-center">
                  {emp.department}
                </td>
                <td className="p-3 text-center">
                  {emp.designation}
                </td>
                <td
                  className={`p-3 text-center font-medium ${
                    emp.status === "Active"
                      ? "text-green-600"
                      : "text-red-600"
                  }`}
                >
                  {emp.status}
                </td>
                <td className="p-3 text-center space-x-3">
                  <button
                    className="text-blue-600"
                    onClick={() =>
                      navigate(`/admin/employees/${emp.id}`)
                    }
                  >
                    View
                  </button>

                  <button
                    className={
                      emp.status === "Active"
                        ? "text-red-600"
                        : "text-green-600"
                    }
                    onClick={() => toggleStatus(emp.id)}
                  >
                    {emp.status === "Active"
                      ? "Disable"
                      : "Enable"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Employee Modal */}
      {showAddModal && (
        <AddEmployeeModal
          onClose={() => setShowAddModal(false)}
          onAdd={(newEmployee) =>
            setEmployees((prev) => [...prev, newEmployee])
          }
        />
      )}
    </div>
  );
};

export default EmployeeManagement;
