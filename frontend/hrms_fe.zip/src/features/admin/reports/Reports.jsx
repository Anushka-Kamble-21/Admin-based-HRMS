import AttendanceChart from "../../../components/charts/AttendanceChart";
import WorkforceChart from "../../../components/charts/WorkforceChart";

const Reports = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Reports & Analytics</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm lg:col-span-2">
          <h2 className="font-semibold mb-4">
            Monthly Attendance Overview
          </h2>
          <AttendanceChart />
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h2 className="font-semibold mb-4">
            Workforce Distribution
          </h2>
          <WorkforceChart />
        </div>
      </div>
    </div>
  );
};

export default Reports;
