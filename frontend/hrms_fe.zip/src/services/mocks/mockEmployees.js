export const employees = [
  {
    id: "emp1",
    name: "Andrew Miles",
    department: "HR",
    designation: "HR Manager",
    dateOfJoining: "2023-01-15",
    dob: "1995-06-20",
    salary: 45000,
    status: "Active",
    bankDetails: {
      bankName: "HDFC Bank",
      branch: "Mumbai",
      accountNumber: "1234567890",
      ifsc: "HDFC0001234"
    }
  },
  {
    id: "emp2",
    name: "Kristin James",
    department: "Engineering",
    designation: "Software Engineer",
    dateOfJoining: "2022-07-10",
    dob: "1998-03-12",
    salary: 60000,
    status: "Disabled",
    bankDetails: null
  }
];
