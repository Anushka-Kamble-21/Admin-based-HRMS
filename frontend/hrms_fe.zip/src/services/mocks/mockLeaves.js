const mockLeaveUsage = {
  "1": 0,
  "2": 1
};

export default mockLeaveUsage;
