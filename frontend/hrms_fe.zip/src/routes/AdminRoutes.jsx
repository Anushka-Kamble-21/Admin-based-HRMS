import { Routes, Route, Navigate } from "react-router-dom";
import AdminLayout from "../components/layout/AdminLayout";
import Dashboard from "../features/admin/dashboard/Dashboard";
import Attendance from "../features/admin/attendance/Attendance";
import EmployeeManagement from "../features/admin/employeeManagement/EmployeeManagement";
import LeaveManagement from "../features/admin/leaveManagement/LeaveManagement";
import Payroll from "../features/admin/payroll/Payroll";
import Reports from "../features/admin/reports/Reports";
import Profile from "../features/admin/profile/Profile";
import PersonalDetails from "../features/admin/profile/PersonalDetails";
import ContactDetails from "../features/admin/profile/ContactDetails";
import EducationDetails from "../features/admin/profile/EducationDetails";
import JobDetails from "../features/admin/profile/JobDetails";
import UpdateProfile from "../features/admin/profile/UpdateProfile";
import EmployeeProfile from "../features/admin/employeeManagement/EmployeeProfile";

const AdminRoutes = () => {
  return (
    <Routes>
      {/* Redirect root to admin dashboard */}
      <Route path="/" element={<Navigate to="/admin/dashboard" />} />

      <Route path="/admin" element={<AdminLayout />}>
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="attendance" element={<Attendance />} />
        <Route path="employees" element={<EmployeeManagement />} />
      
        <Route path="employees/:id" element={<EmployeeProfile />} />

        <Route path="leaves" element={<LeaveManagement />} />
        <Route path="payroll" element={<Payroll />} />
        <Route path="reports" element={<Reports />} />
 
        <Route path="profile" element={<Profile />}>
          <Route path="personal" element={<PersonalDetails />} />
          <Route path="contact" element={<ContactDetails />} />
          <Route path="education" element={<EducationDetails />} />
          <Route path="job" element={<JobDetails />} />
          <Route path="update" element={<UpdateProfile />} />
        </Route>
      </Route>
    </Routes>
  );
};  

export default AdminRoutes;
